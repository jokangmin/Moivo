package com.example.demo.qna.service;

public interface QuestionService {

}
