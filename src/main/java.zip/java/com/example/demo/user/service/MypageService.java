package com.example.demo.user.service;

public interface MypageService {

}
