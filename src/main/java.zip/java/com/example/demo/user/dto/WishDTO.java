package com.example.demo.user.dto;

public class WishDTO {

}
