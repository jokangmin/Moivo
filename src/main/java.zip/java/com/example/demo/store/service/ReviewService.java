package com.example.demo.store.service;

public interface ReviewService {

}
