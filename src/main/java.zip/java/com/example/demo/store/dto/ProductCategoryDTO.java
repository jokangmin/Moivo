package com.example.demo.store.dto;

public class ProductCategoryDTO {

}
