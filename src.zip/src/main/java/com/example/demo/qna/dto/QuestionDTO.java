package com.example.demo.qna.dto;

public class QuestionDTO {

}
