package com.example.demo.qna.service.impl;

import org.springframework.stereotype.Service;

import com.example.demo.qna.service.QuestionService;

@Service
public class QuestionServiceImpl implements QuestionService {

}
