package com.example.demo.user.service;

public interface CartService {

}
