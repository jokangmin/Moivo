package com.example.demo.user.dto;

public class AttendanceDTO { // 출석

}
