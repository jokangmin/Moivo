package com.example.demo.user.dto;

public class CartDTO { // 장바구니

}
