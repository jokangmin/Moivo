package com.example.demo.store.dto;

public class CategoryDTO { // 카테고리

}
