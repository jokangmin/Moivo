package com.example.demo.store.dto;

public class ReviewDTO { // 리뷰

}
