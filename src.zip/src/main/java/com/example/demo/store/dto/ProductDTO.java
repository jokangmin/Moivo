package com.example.demo.store.dto;

public class ProductDTO { // 상품

}
