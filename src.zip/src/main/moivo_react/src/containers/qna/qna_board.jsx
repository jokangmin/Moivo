import React from 'react';

const qna_board = () => {
    return (
        <div>
            
        </div>
    );
};

export default qna_board;