import React from 'react';
import Banner from './../../components/Banner/banner';
import Footer from './../../components/Footer/Footer';

const prodict_search = () => {
     return (
          <div>
               <Banner />
               상품을 검색하세요

               전체 상품 중 검색하기...

               검색 바 , 검색 아이콘 넣기

               검색 바 에 알맞은 텍스트 입력시 해당 값을 가지고 DB에서 검색하기
               <div>
               <Footer />
               </div>
          </div>
     );
};

export default prodict_search;